# seat
online seat selector, a plugin for web apps and mobile apps, developed with jQuery and HTML
web site address is http://html5.mtooa.com
